*****************************************************************************
* Annotated partially by: Alexandru Cristian Cosma, Vlad Vasile Itu and Darius Suciu, 2014.
*		Department of Computer Sicence
*               Technical University of Cluj Napoca             
*
* Contact: Darius Suciu, darius.suciu04@gmail.com 
	   Alexandru Cristian Cosma, alexx.cosma@gmail.com
           Vlad Vasile Itu, itu.vlad@gmail.com
*     
*****************************************************************************

                            Readme file - annotated datasets

This folder contains: 

-Product Reviews: annotated customer reviews of 4 products:
	1. digital camera: Canon G3
	2. digital camera: Nikon coolpix 4300
	3. celluar phone:  Nokia 6610
	4. dvd player:     Apex AD2600 Progressive-scan DVD player

- Movie Reviews: 8 annotated movie reviews, both in separate files and merged into one

- Polarity Assignment Test Data: annotated customer reviews of 2 products for polarity evaluation:
        1. DataSet1: A fraction of the Nikon coolpix 4300 reviews
        2. DataSet2: A fraction of the Canon reviews

All the reviews were from amazon.com. Datasets 1 and 3 are obtained from the same original source 
(which was partially annotated by Liu et. al for target extraction - see corresponding folder). 
We have added anotations for opinion words.

Symbols used in the annotated reviews:

	For opinion word and target extraction:
  		###opinionword: opinionword is an adjective or adverb that can express an opinion.
  		%%%feature: feature is the target of an opinion word.
	For polarity assignment:
  		opinionword@value: value is the opinion polarity of the respective opinion word



