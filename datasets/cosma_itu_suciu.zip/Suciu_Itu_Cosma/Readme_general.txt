*****************************************************************************
* Datasets obtained and annotated partially by: Alexandru Cristian Cosma, Vlad Vasile Itu and Darius Suciu, 2014.
*		Department of Computer Sicence
*               Technical University of Cluj Napoca             
*
* Contact: Darius Suciu, darius.suciu04@gmail.com 
	   Alexandru Cristian Cosma, alexx.cosma@gmail.com
           Vlad Vasile Itu, itu.vlad@gmail.com
*     
*****************************************************************************

                            General readme file

The archive contains the following three datasets: Product Reviews, Movie Reviews and Polarity Assignment Test Data. 
All the reviews were from amazon.com. Both the original reviews and the annotated datasets are available in the archive.
Some annotations were performed by us, some were obtained from other sources, which are appropriately cited in the corresponding 
Readme.txt files. 
Further information in the Readme.txt files in the folders.
